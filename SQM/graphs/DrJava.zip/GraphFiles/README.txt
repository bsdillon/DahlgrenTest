All of these files come from Dr. Java which is an open source tool.

The GPH file is built from the compiled code and represents all the relationships available in the code.

The Node and Edge files are derived from the GPH and they represent the essential elements of code.
* I care about functions and fields.
* I don't care about how functions are part of a class.

The way SQM outputs the graph, all edges are in the one file.
Nodes from the graph are brought out in different groups that may be of interest to you (or not).
* API classes are disconnected from the rest of the code and may only be implemented externally (if at all).
* External code is anything referenced within the code which exists elsewhere. This includes any library not part of the code we are examining, but it also excludes all the knowledge of the external libraries. Theoretically we could be missing paths that connect through the external code.
* Interfaces are a special case in software because they provide a buffer between sub-graphs of code. In an ideal case good interfaces can reduce everything to trivial subgraphs with easily proven characteristics. We look at them separately because they aren't really code, just a buffer.
* Tumor contains code that has been tagged as BAD for various reasons. From a graph perspective, I'm looking for anything that tends to violate the separation of subgraphs. I want to see good separation, but these nodes tend to connect things without justification.
* Module contains everything else.

Cancer_Tumor node and edge was an effort to isolate just the bad sections of code and the subgraphs they link.
