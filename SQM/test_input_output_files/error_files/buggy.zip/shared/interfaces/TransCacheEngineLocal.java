package com.flexive.shared.interfaces;

import javax.ejb.Local;

/**
 * Local interface of {@link TransCacheEngine}.
 *
 * @author Daniel Lichtenberger, UCS
 * @version $Rev: 2982 $
 */
@Local
public interface TransCacheEngineLocal extends TransCacheEngine {
}
