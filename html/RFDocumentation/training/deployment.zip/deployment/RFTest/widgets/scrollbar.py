from widget import Widget

class ScrollBar(Widget):

    def __init__(self, name:str, imageLibrary):
        raise NotImplementedError("ScrollBar is deprecated")
