from widget import Widget

class DropDown(Widget):
    ROBOT_AUTO_KEYWORDS = False

    def __init__(self, name:str, imageLibrary):
        raise NotImplementedError("DropDown is deprecated")