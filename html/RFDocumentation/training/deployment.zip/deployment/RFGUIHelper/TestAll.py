from widget import Widget

print("Testing Widget")
test = Widget("testing", "type", 2, 3, 22, 33, "")
test.print()