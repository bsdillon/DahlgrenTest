from django.apps import AppConfig


class PrototypeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'prototype'
