from django.apps import AppConfig


class LabtestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'labTest'
